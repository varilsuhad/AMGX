#include <type_traits>
#include <atomic>
#include <thread>

int main() {
    return 0;
}
